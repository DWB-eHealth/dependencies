[![Build Status](https://travis-ci.org/openmrs/openmrs-module-uicommons.svg?branch=master)](https://travis-ci.org/openmrs/openmrs-module-uicommons)

openmrs-module-uicommons
========================

UI Library that has common JS/CSS/HTML/templates/fragments etc.
